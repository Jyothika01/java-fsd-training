export default class Greeter {
    constructor(public greeting: string) { }

    greet() {
        return this.greeting;
    }
}

