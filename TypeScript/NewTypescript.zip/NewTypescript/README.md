# codemix-vanilla-typescript

Template for project creation of Typescript inside CodeMix

## Contents

This template project is just an example Hello World that guide you through the use of typescript and nodejs to build a very simple console application that display a Hello World!!! Greeting
