package com.example.SpringBootClinic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootClinicApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootClinicApplication.class, args);
	}

}
